<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             67b7ad7e28ff2             |
    |_______________________________________|
*/
 use Pmpr\Module\Salary\Salary; Salary::symcgieuakksimmu();
