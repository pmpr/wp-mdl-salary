<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66eae92821925             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Salary\Profile; use Pmpr\Module\Salary\Container; class Common extends Container { }
