<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66ce11ba45ec2             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Salary\Profile; use Pmpr\Module\Salary\Container; class Common extends Container { }
