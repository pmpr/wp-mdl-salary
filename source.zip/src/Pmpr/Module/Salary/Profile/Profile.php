<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6684010874872             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Salary\Profile; use Pmpr\Module\Salary\Profile\Panel\Panel; class Profile extends Common { public function mameiwsayuyquoeq() { if (!(!$this->uwkmaywceaaaigwo()->owicscwgeuqcqaig()->goecwaaykqoaaagg() && $this->omseesogaocascyo("\160\141\156\145\154"))) { goto gswcoeiisamakwii; } Panel::symcgieuakksimmu(); gswcoeiisamakwii: } }
