<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66ce11ba45ec2             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Salary\Profile; use Pmpr\Module\Salary\Profile\Panel\Panel; class Profile extends Common { public function mameiwsayuyquoeq() { if (!(!$this->uwkmaywceaaaigwo()->owicscwgeuqcqaig()->goecwaaykqoaaagg() && $this->omseesogaocascyo("\160\x61\x6e\145\x6c"))) { goto ekakkiuuquqkccse; } Panel::symcgieuakksimmu(); ekakkiuuquqkccse: } }
