<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66e5ec9b93467             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Salary\Profile; use Pmpr\Module\Salary\Profile\Panel\Panel; class Profile extends Common { public function mameiwsayuyquoeq() { if (!(!$this->uwkmaywceaaaigwo()->owicscwgeuqcqaig()->goecwaaykqoaaagg() && $this->omseesogaocascyo("\160\141\156\x65\x6c"))) { goto sggawugoykqcmsug; } Panel::symcgieuakksimmu(); sggawugoykqcmsug: } }
