<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66cb56f37f35d             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Salary\Profile; use Pmpr\Module\Salary\Profile\Panel\Panel; class Profile extends Common { public function mameiwsayuyquoeq() { if (!(!$this->uwkmaywceaaaigwo()->owicscwgeuqcqaig()->goecwaaykqoaaagg() && $this->omseesogaocascyo("\x70\x61\x6e\x65\x6c"))) { goto cakuguiciaiaeukg; } Panel::symcgieuakksimmu(); cakuguiciaiaeukg: } }
