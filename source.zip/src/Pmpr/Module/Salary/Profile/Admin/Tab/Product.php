<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             67abce985ecd6             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Salary\Profile\Admin\Tab; use Pmpr\Module\Salary\Profile\Admin\ListTable\ProductListTable; class Product extends Tab { public function __construct() { $this->id = "\160\162\x6f\x64\x75\143\x74\x73"; $this->title = __("\x50\162\157\144\x75\143\164\x73", PR__MDL__SALARY); $this->priority = 50; parent::__construct(); } public function gayqqwwuycceosii() : array { $qsyooiqcmkcieyuk = new ProductListTable(); return ["\154\151\x73\x74\137\x74\x61\x62\x6c\x65" => $qsyooiqcmkcieyuk]; } }
