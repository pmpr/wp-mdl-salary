<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             660699ababe7d             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Salary\Profile\Admin\Tab; use Pmpr\Module\Salary\Profile\Admin\ListTable\ProductListTable; class Product extends Tab { public function __construct() { $this->id = "\x70\x72\x6f\144\165\x63\164\x73"; $this->title = __("\120\x72\x6f\x64\165\143\x74\x73", PR__MDL__SALARY); $this->priority = 50; parent::__construct(); } public function gayqqwwuycceosii() : array { $qsyooiqcmkcieyuk = new ProductListTable(); return ["\154\151\x73\x74\x5f\164\x61\x62\154\x65" => $qsyooiqcmkcieyuk]; } }
