<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             660699ababe7d             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Salary\Profile\Admin\ListTable; use Pmpr\Module\Salary\Model\Withdraw; class WithdrawListTable extends ORMListTable { public function get_columns() : array { $wkkweuacukumqmya = []; $meywaqqsugaoeyys = $this->mgogaykgkoogasim(); if (!$meywaqqsugaoeyys instanceof Withdraw) { goto kwmiwaecqcgiaqye; } $oammesyieqmwuwyi = [$meywaqqsugaoeyys::owmueawayysqcsqo, $meywaqqsugaoeyys::aioqyewkwawaqgqe => __("\x41\155\157\x75\x6e\164", PR__MDL__SALARY), $meywaqqsugaoeyys::ciywsqoeiymemsys]; $wkkweuacukumqmya = $this->ewgmueueeycoikso($oammesyieqmwuwyi); kwmiwaecqcgiaqye: return $wkkweuacukumqmya; } }
