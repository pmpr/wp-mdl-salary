<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             670d8a2d30a04             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Salary\Profile\Admin\ListTable; use Pmpr\Common\Foundation\Interfaces\Constants; use Pmpr\Module\Salary\Model\Withdraw; class WithdrawListTable extends ORMListTable { public function get_columns() : array { $wkkweuacukumqmya = []; $meywaqqsugaoeyys = $this->mgogaykgkoogasim(); if ($meywaqqsugaoeyys instanceof Withdraw) { $oammesyieqmwuwyi = [$meywaqqsugaoeyys::owmueawayysqcsqo, Constants::aioqyewkwawaqgqe => __("\101\155\x6f\x75\156\164", PR__MDL__SALARY), Constants::ciywsqoeiymemsys]; $wkkweuacukumqmya = $this->ewgmueueeycoikso($oammesyieqmwuwyi); } return $wkkweuacukumqmya; } }
