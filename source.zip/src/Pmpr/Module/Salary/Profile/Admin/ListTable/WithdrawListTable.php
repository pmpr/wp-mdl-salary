<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             668708366d2ab             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Salary\Profile\Admin\ListTable; use Pmpr\Module\Salary\Model\Withdraw; class WithdrawListTable extends ORMListTable { public function get_columns() : array { $wkkweuacukumqmya = []; $meywaqqsugaoeyys = $this->mgogaykgkoogasim(); if (!$meywaqqsugaoeyys instanceof Withdraw) { goto asaowisseacciyia; } $oammesyieqmwuwyi = [$meywaqqsugaoeyys::owmueawayysqcsqo, $meywaqqsugaoeyys::aioqyewkwawaqgqe => __("\x41\x6d\157\165\x6e\164", PR__MDL__SALARY), $meywaqqsugaoeyys::ciywsqoeiymemsys]; $wkkweuacukumqmya = $this->ewgmueueeycoikso($oammesyieqmwuwyi); asaowisseacciyia: return $wkkweuacukumqmya; } }
