<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             668708366d2ab             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Salary\Profile\Admin\ListTable; use Pmpr\Module\Salary\Model\Income; class IncomeListTable extends ORMListTable { public function get_columns() : array { $wkkweuacukumqmya = []; $meywaqqsugaoeyys = $this->mgogaykgkoogasim(); if (!$meywaqqsugaoeyys instanceof Income) { goto acesyuieuuqwgkwm; } $oammesyieqmwuwyi = [$meywaqqsugaoeyys::awkcoioakcaougmq, $meywaqqsugaoeyys::oguseymmyyoyaako, $meywaqqsugaoeyys::aioqyewkwawaqgqe, $meywaqqsugaoeyys::eiiuyoyiygsickwe]; $wkkweuacukumqmya = $this->ewgmueueeycoikso($oammesyieqmwuwyi); acesyuieuuqwgkwm: return $wkkweuacukumqmya; } }
