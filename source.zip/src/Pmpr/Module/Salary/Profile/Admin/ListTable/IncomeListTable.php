<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6684010874872             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Salary\Profile\Admin\ListTable; use Pmpr\Module\Salary\Model\Income; class IncomeListTable extends ORMListTable { public function get_columns() : array { $wkkweuacukumqmya = []; $meywaqqsugaoeyys = $this->mgogaykgkoogasim(); if (!$meywaqqsugaoeyys instanceof Income) { goto acesyuieuuqwgkwm; } $oammesyieqmwuwyi = [$meywaqqsugaoeyys::awkcoioakcaougmq, $meywaqqsugaoeyys::oguseymmyyoyaako, $meywaqqsugaoeyys::aioqyewkwawaqgqe, $meywaqqsugaoeyys::eiiuyoyiygsickwe]; $wkkweuacukumqmya = $this->ewgmueueeycoikso($oammesyieqmwuwyi); acesyuieuuqwgkwm: return $wkkweuacukumqmya; } }
