<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             661e423b713ee             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Salary\Profile\Admin\ListTable; use Pmpr\Module\Salary\Model\Income; class IncomeListTable extends ORMListTable { public function get_columns() : array { $wkkweuacukumqmya = []; $meywaqqsugaoeyys = $this->mgogaykgkoogasim(); if (!$meywaqqsugaoeyys instanceof Income) { goto cquecqekuucwoumw; } $oammesyieqmwuwyi = [$meywaqqsugaoeyys::awkcoioakcaougmq, $meywaqqsugaoeyys::oguseymmyyoyaako, $meywaqqsugaoeyys::aioqyewkwawaqgqe, $meywaqqsugaoeyys::eiiuyoyiygsickwe]; $wkkweuacukumqmya = $this->ewgmueueeycoikso($oammesyieqmwuwyi); cquecqekuucwoumw: return $wkkweuacukumqmya; } }
