<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             67b7ad7e28ff2             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Salary\Profile\Admin\ListTable; use Pmpr\Common\Foundation\Interfaces\Constants; use Pmpr\Module\Salary\Model\Income; class IncomeListTable extends ORMListTable { public function get_columns() : array { $wkkweuacukumqmya = []; $meywaqqsugaoeyys = $this->mgogaykgkoogasim(); if ($meywaqqsugaoeyys instanceof Income) { $oammesyieqmwuwyi = [Constants::awkcoioakcaougmq, Constants::oguseymmyyoyaako, Constants::aioqyewkwawaqgqe, $meywaqqsugaoeyys::eiiuyoyiygsickwe]; $wkkweuacukumqmya = $this->ewgmueueeycoikso($oammesyieqmwuwyi); } return $wkkweuacukumqmya; } }
