<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66e5ec9b93467             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Salary\Profile\Admin\ListTable; use Pmpr\Module\Salary\Model\Income; class IncomeListTable extends ORMListTable { public function get_columns() : array { $wkkweuacukumqmya = []; $meywaqqsugaoeyys = $this->mgogaykgkoogasim(); if (!$meywaqqsugaoeyys instanceof Income) { goto ykomgumacooyomsk; } $oammesyieqmwuwyi = [$meywaqqsugaoeyys::awkcoioakcaougmq, $meywaqqsugaoeyys::oguseymmyyoyaako, $meywaqqsugaoeyys::aioqyewkwawaqgqe, $meywaqqsugaoeyys::eiiuyoyiygsickwe]; $wkkweuacukumqmya = $this->ewgmueueeycoikso($oammesyieqmwuwyi); ykomgumacooyomsk: return $wkkweuacukumqmya; } }
