<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6684010874872             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Salary; use Pmpr\Common\Foundation\Container\ComponentInitiator; use Pmpr\Module\Salary\Model\Model; use Pmpr\Module\Salary\Profile\Profile; class Salary extends ComponentInitiator { public function register() { $this->gkieogwukagigisy(__DIR__, [self::qescuiwgsyuikume => static function () { return __("\123\141\x6c\141\x72\x79", PR__MDL__SALARY); }]); } public function wigskegsqequoeks() { $this->qcsmikeggeemccuu("\160\x6c\x75\147\x69\x6e\x73\x5f\x6c\157\x61\x64\x65\144", [$this, "\151\143\x77\143\147\155\143\x6f\x69\155\161\145\x69\x67\x79\x65"]); } public function icwcgmcoimqeigye() { if (!$this->uwkmaywceaaaigwo()->owicscwgeuqcqaig()->goecwaaykqoaaagg()) { goto ayyweymyuuiauamo; } Setting::symcgieuakksimmu(); ayyweymyuuiauamo: if (!$this->caokeucsksukesyo()->wikusamwomuogoau()->ggocakcisguuokai()) { goto omugkkesagcyagmk; } User::symcgieuakksimmu(); Model::symcgieuakksimmu(); Asset::symcgieuakksimmu(); Profile::symcgieuakksimmu(); Product::symcgieuakksimmu(); if (!$this->caokeucsksukesyo()->owicscwgeuqcqaig()->mcgoysmkqsqooceq()) { goto mosqsmqimqgqoase; } Ajax::symcgieuakksimmu(); mosqsmqimqgqoase: omugkkesagcyagmk: } }
