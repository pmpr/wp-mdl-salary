<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6646a8b94f100             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Salary; use Pmpr\Common\Foundation\Container\ComponentInitiator; use Pmpr\Module\Salary\Model\Model; use Pmpr\Module\Salary\Profile\Profile; class Salary extends ComponentInitiator { public function register() { $this->gkieogwukagigisy(__DIR__, [self::qescuiwgsyuikume => static function () { return __("\x53\x61\154\141\x72\171", PR__MDL__SALARY); }]); } public function wigskegsqequoeks() { $this->qcsmikeggeemccuu("\x70\154\165\147\151\156\x73\x5f\154\x6f\141\x64\x65\144", [$this, "\151\143\x77\x63\x67\155\x63\x6f\151\x6d\x71\145\151\x67\171\145"]); } public function icwcgmcoimqeigye() { if (!$this->uwkmaywceaaaigwo()->owicscwgeuqcqaig()->goecwaaykqoaaagg()) { goto cecuyayqoioasumi; } Setting::symcgieuakksimmu(); cecuyayqoioasumi: if (!$this->caokeucsksukesyo()->wikusamwomuogoau()->ggocakcisguuokai()) { goto qogqewiwmwiwskgm; } User::symcgieuakksimmu(); Model::symcgieuakksimmu(); Asset::symcgieuakksimmu(); Profile::symcgieuakksimmu(); Product::symcgieuakksimmu(); if (!$this->caokeucsksukesyo()->owicscwgeuqcqaig()->mcgoysmkqsqooceq()) { goto qiaqsassksqiuyae; } Ajax::symcgieuakksimmu(); qiaqsassksqiuyae: qogqewiwmwiwskgm: } }
