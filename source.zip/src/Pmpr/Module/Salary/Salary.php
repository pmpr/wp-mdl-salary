<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             668708366d2ab             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Salary; use Pmpr\Common\Foundation\Container\ComponentInitiator; use Pmpr\Module\Salary\Model\Model; use Pmpr\Module\Salary\Profile\Profile; class Salary extends ComponentInitiator { public function register() { $this->gkieogwukagigisy(__DIR__, [self::qescuiwgsyuikume => static function () { return __("\x53\141\154\x61\x72\x79", PR__MDL__SALARY); }]); } public function wigskegsqequoeks() { $this->qcsmikeggeemccuu("\x70\x6c\165\x67\151\x6e\x73\137\154\x6f\141\x64\145\144", [$this, "\151\x63\x77\143\x67\x6d\143\157\x69\155\161\x65\x69\x67\171\145"]); } public function icwcgmcoimqeigye() { if (!$this->uwkmaywceaaaigwo()->owicscwgeuqcqaig()->goecwaaykqoaaagg()) { goto ayyweymyuuiauamo; } Setting::symcgieuakksimmu(); ayyweymyuuiauamo: if (!$this->caokeucsksukesyo()->wikusamwomuogoau()->ggocakcisguuokai()) { goto omugkkesagcyagmk; } User::symcgieuakksimmu(); Model::symcgieuakksimmu(); Asset::symcgieuakksimmu(); Profile::symcgieuakksimmu(); Product::symcgieuakksimmu(); if (!$this->caokeucsksukesyo()->owicscwgeuqcqaig()->mcgoysmkqsqooceq()) { goto mosqsmqimqgqoase; } Ajax::symcgieuakksimmu(); mosqsmqimqgqoase: omugkkesagcyagmk: } }
