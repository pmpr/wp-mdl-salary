<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             660699ababe7d             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Salary; use Pmpr\Common\Foundation\Container\ComponentInitiator; use Pmpr\Module\Salary\Model\Model; use Pmpr\Module\Salary\Profile\Profile; class Salary extends ComponentInitiator { public function register() { $this->gkieogwukagigisy(__DIR__, [self::qescuiwgsyuikume => static function () { return __("\x53\x61\154\x61\x72\171", PR__MDL__SALARY); }]); } public function wigskegsqequoeks() { $this->qcsmikeggeemccuu("\160\x6c\165\147\151\x6e\x73\137\x6c\157\x61\x64\x65\x64", [$this, "\x69\143\x77\x63\x67\155\143\157\151\155\x71\x65\151\147\171\145"]); } public function icwcgmcoimqeigye() { if (!$this->uwkmaywceaaaigwo()->owicscwgeuqcqaig()->goecwaaykqoaaagg()) { goto wkwamkgkwykeqkec; } Setting::symcgieuakksimmu(); wkwamkgkwykeqkec: if (!$this->caokeucsksukesyo()->wikusamwomuogoau()->ggocakcisguuokai()) { goto oeocukauoyosicso; } User::symcgieuakksimmu(); Model::symcgieuakksimmu(); Asset::symcgieuakksimmu(); Profile::symcgieuakksimmu(); Product::symcgieuakksimmu(); if (!$this->caokeucsksukesyo()->owicscwgeuqcqaig()->mcgoysmkqsqooceq()) { goto oimkeqocuguqqsqk; } Ajax::symcgieuakksimmu(); oimkeqocuguqqsqk: oeocukauoyosicso: } }
