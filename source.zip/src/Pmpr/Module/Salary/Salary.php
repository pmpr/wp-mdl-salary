<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66b3f9e904396             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Salary; use Pmpr\Common\Foundation\Container\ComponentInitiator; use Pmpr\Module\Salary\Model\Model; use Pmpr\Module\Salary\Profile\Profile; class Salary extends ComponentInitiator { public function register() { $this->gkieogwukagigisy(__DIR__, [self::qescuiwgsyuikume => static function () { return __("\123\x61\154\x61\162\x79", PR__MDL__SALARY); }]); } public function wigskegsqequoeks() { $this->qcsmikeggeemccuu("\160\154\165\x67\x69\x6e\x73\x5f\154\x6f\x61\144\145\144", [$this, "\x69\143\x77\x63\147\155\143\x6f\151\x6d\161\x65\151\147\x79\x65"]); } public function icwcgmcoimqeigye() { if (!$this->uwkmaywceaaaigwo()->owicscwgeuqcqaig()->goecwaaykqoaaagg()) { goto sggawugoykqcmsug; } Setting::symcgieuakksimmu(); sggawugoykqcmsug: if (!$this->caokeucsksukesyo()->wikusamwomuogoau()->ggocakcisguuokai()) { goto wakmayaoqoskekqy; } User::symcgieuakksimmu(); Model::symcgieuakksimmu(); Asset::symcgieuakksimmu(); Profile::symcgieuakksimmu(); Product::symcgieuakksimmu(); if (!$this->caokeucsksukesyo()->owicscwgeuqcqaig()->mcgoysmkqsqooceq()) { goto wkeuuycukmuqiaom; } Ajax::symcgieuakksimmu(); wkeuuycukmuqiaom: wakmayaoqoskekqy: } }
