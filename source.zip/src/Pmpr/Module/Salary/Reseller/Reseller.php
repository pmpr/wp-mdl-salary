<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             668708366d2ab             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Salary\Reseller; class Reseller extends Common { }
