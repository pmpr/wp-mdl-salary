<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6646a8b94f100             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Salary\Reseller; use Pmpr\Module\Salary\Container; abstract class Common extends Container { }
