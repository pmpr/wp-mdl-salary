<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             668c5b6ff0bed             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Salary\Model; use Pmpr\Module\Salary\Container; class Model extends Container { public function mameiwsayuyquoeq() { Agreement::symcgieuakksimmu(); Request::symcgieuakksimmu(); Income::symcgieuakksimmu(); Withdraw::symcgieuakksimmu(); Payment::symcgieuakksimmu(); } }
