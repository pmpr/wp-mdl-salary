<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66e5ec9b93467             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Salary\Model; use Pmpr\Module\Salary\Container; class Model extends Container { public function mameiwsayuyquoeq() { Agreement::symcgieuakksimmu(); Request::symcgieuakksimmu(); Income::symcgieuakksimmu(); Withdraw::symcgieuakksimmu(); Payment::symcgieuakksimmu(); } }
