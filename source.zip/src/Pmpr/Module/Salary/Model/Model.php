<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66cb56f37f35d             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Salary\Model; use Pmpr\Module\Salary\Container; class Model extends Container { public function mameiwsayuyquoeq() { Agreement::symcgieuakksimmu(); Request::symcgieuakksimmu(); Income::symcgieuakksimmu(); Withdraw::symcgieuakksimmu(); Payment::symcgieuakksimmu(); } }
