<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             680106675a767             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Salary; use Pmpr\Common\Foundation\Container\Container as BaseClass; use Pmpr\Common\Foundation\Interfaces\Constants; abstract class Container extends BaseClass { const wyqmcowecikgawuu = 'iban'; const oogeqgcgkamuoaoe = 'bank'; const wagwccqcqwgsoyoi = 'locked'; const cqkcksqwkcsiykuq = 'escaped'; const kuwsqycgaagiimge = 'account'; const skyceaacaaaamiii = 'debit_card'; const qagqayweyigciamg = 'salary_bank_account_information'; const yuqaieqcaccggqck = 'collaborator'; }
