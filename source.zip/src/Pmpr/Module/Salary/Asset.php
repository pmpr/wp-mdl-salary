<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66b3f9e904396             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Salary; class Asset extends Container { public function wigskegsqequoeks() { $this->qcsmikeggeemccuu("\x61\x64\x6d\x69\156\x5f\x69\x6e\151\164", [$this, "\x65\156\161\x75\145\165\x65"]); } public function enqueue() { if (!($eygsasmqycagyayw = $this->miocmcoykayoyyau())) { goto ueigkucgaucgeimc; } $eygsasmqycagyayw->ayeieigcckcmsikq($eygsasmqycagyayw->owygwqwawqoiusis("\141\144\x6d\151\156", $eygsasmqycagyayw->get("\x61\144\x6d\x69\x6e\56\x6a\163"))->simswskycwagoeqy())->ikqyiskqaaymscgw("\141\x6a\x61\170", Ajax::myikkigscysoykgy); ueigkucgaucgeimc: } }
