<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66cb56f37f35d             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Salary; class Asset extends Container { public function wigskegsqequoeks() { $this->qcsmikeggeemccuu("\x61\144\155\x69\156\137\x69\156\151\164", [$this, "\145\x6e\x71\x75\145\165\x65"]); } public function enqueue() { if (!($eygsasmqycagyayw = $this->miocmcoykayoyyau())) { goto ueigkucgaucgeimc; } $eygsasmqycagyayw->ayeieigcckcmsikq($eygsasmqycagyayw->owygwqwawqoiusis("\141\144\155\151\156", $eygsasmqycagyayw->get("\141\x64\x6d\x69\156\x2e\x6a\x73"))->simswskycwagoeqy())->ikqyiskqaaymscgw("\141\152\x61\170", Ajax::myikkigscysoykgy); ueigkucgaucgeimc: } }
