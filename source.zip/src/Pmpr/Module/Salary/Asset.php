<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             660699ababe7d             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Salary; class Asset extends Container { public function wigskegsqequoeks() { $this->qcsmikeggeemccuu("\x61\144\x6d\151\156\x5f\x69\x6e\151\x74", [$this, "\145\x6e\161\165\145\165\145"]); } public function enqueue() { if (!($eygsasmqycagyayw = $this->miocmcoykayoyyau())) { goto msemumccgceyugmg; } $eygsasmqycagyayw->ayeieigcckcmsikq($eygsasmqycagyayw->owygwqwawqoiusis("\141\144\155\151\156", $eygsasmqycagyayw->get("\x61\x64\155\151\x6e\56\x6a\x73"))->simswskycwagoeqy())->ikqyiskqaaymscgw("\x61\x6a\x61\170", Ajax::myikkigscysoykgy); msemumccgceyugmg: } }
