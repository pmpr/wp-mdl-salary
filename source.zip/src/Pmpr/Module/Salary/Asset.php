<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6654cb66de764             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Salary; class Asset extends Container { public function wigskegsqequoeks() { $this->qcsmikeggeemccuu("\141\x64\x6d\x69\156\137\151\156\x69\164", [$this, "\145\156\x71\x75\145\x75\145"]); } public function enqueue() { if (!($eygsasmqycagyayw = $this->miocmcoykayoyyau())) { goto yowsmsiyimmimemc; } $eygsasmqycagyayw->ayeieigcckcmsikq($eygsasmqycagyayw->owygwqwawqoiusis("\x61\x64\x6d\151\156", $eygsasmqycagyayw->get("\141\144\x6d\151\x6e\56\x6a\163"))->simswskycwagoeqy())->ikqyiskqaaymscgw("\141\152\x61\x78", Ajax::myikkigscysoykgy); yowsmsiyimmimemc: } }
