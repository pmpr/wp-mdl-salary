<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             661e423b713ee             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Salary; class Asset extends Container { public function wigskegsqequoeks() { $this->qcsmikeggeemccuu("\x61\x64\155\x69\x6e\137\151\x6e\x69\x74", [$this, "\x65\156\161\x75\145\x75\145"]); } public function enqueue() { if (!($eygsasmqycagyayw = $this->miocmcoykayoyyau())) { goto cecuyayqoioasumi; } $eygsasmqycagyayw->ayeieigcckcmsikq($eygsasmqycagyayw->owygwqwawqoiusis("\x61\144\x6d\x69\x6e", $eygsasmqycagyayw->get("\141\144\155\151\156\56\152\x73"))->simswskycwagoeqy())->ikqyiskqaaymscgw("\141\152\141\170", Ajax::myikkigscysoykgy); cecuyayqoioasumi: } }
