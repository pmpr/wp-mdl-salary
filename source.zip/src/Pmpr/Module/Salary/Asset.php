<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6646a8b94f100             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Salary; class Asset extends Container { public function wigskegsqequoeks() { $this->qcsmikeggeemccuu("\141\144\155\151\156\x5f\151\x6e\x69\x74", [$this, "\x65\156\161\165\145\x75\x65"]); } public function enqueue() { if (!($eygsasmqycagyayw = $this->miocmcoykayoyyau())) { goto yowsmsiyimmimemc; } $eygsasmqycagyayw->ayeieigcckcmsikq($eygsasmqycagyayw->owygwqwawqoiusis("\x61\x64\155\151\156", $eygsasmqycagyayw->get("\x61\144\155\151\156\x2e\152\163"))->simswskycwagoeqy())->ikqyiskqaaymscgw("\141\152\x61\170", Ajax::myikkigscysoykgy); yowsmsiyimmimemc: } }
