<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66e5ec9b93467             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Salary; class Asset extends Container { public function wigskegsqequoeks() { $this->waqewsckuayqguos("\142\x65\x66\x6f\162\145\137\145\156\x71\x75\x65\165\x65\x5f\x62\141\143\x6b\145\x6e\144\137\141\163\163\x65\x74\163", [$this, "\x65\x6e\x71\x75\x65\165\x65"]); } public function enqueue() { if (!($eygsasmqycagyayw = $this->miocmcoykayoyyau())) { goto sciwggaeogcoesiu; } $eygsasmqycagyayw->ayeieigcckcmsikq($eygsasmqycagyayw->owygwqwawqoiusis("\141\144\155\151\x6e", $eygsasmqycagyayw->get("\141\x64\x6d\151\156\x2e\152\x73"))->simswskycwagoeqy())->ikqyiskqaaymscgw("\141\x6a\141\x78", Ajax::myikkigscysoykgy); sciwggaeogcoesiu: } }
