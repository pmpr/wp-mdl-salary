<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             668708366d2ab             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Salary; class Asset extends Container { public function wigskegsqequoeks() { $this->qcsmikeggeemccuu("\141\144\155\151\156\x5f\x69\x6e\x69\164", [$this, "\145\x6e\161\x75\145\x75\145"]); } public function enqueue() { if (!($eygsasmqycagyayw = $this->miocmcoykayoyyau())) { goto eyiamcekkgkiawqy; } $eygsasmqycagyayw->ayeieigcckcmsikq($eygsasmqycagyayw->owygwqwawqoiusis("\141\x64\x6d\x69\x6e", $eygsasmqycagyayw->get("\x61\144\155\x69\x6e\56\152\x73"))->simswskycwagoeqy())->ikqyiskqaaymscgw("\x61\152\x61\170", Ajax::myikkigscysoykgy); eyiamcekkgkiawqy: } }
