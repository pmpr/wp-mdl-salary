<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66eae92821925             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Salary; class Asset extends Container { public function wigskegsqequoeks() { $this->waqewsckuayqguos("\142\145\146\x6f\x72\145\137\145\x6e\x71\165\145\165\x65\x5f\x62\x61\143\153\145\156\x64\x5f\141\163\163\145\164\163", [$this, "\145\156\161\x75\145\165\x65"]); } public function enqueue() { if (!($eygsasmqycagyayw = $this->miocmcoykayoyyau())) { goto sciwggaeogcoesiu; } $eygsasmqycagyayw->ayeieigcckcmsikq($eygsasmqycagyayw->owygwqwawqoiusis("\x61\x64\x6d\151\156", $eygsasmqycagyayw->get("\x61\144\155\151\x6e\x2e\152\x73"))->simswskycwagoeqy())->ikqyiskqaaymscgw("\x61\152\x61\x78", Ajax::myikkigscysoykgy); sciwggaeogcoesiu: } }
