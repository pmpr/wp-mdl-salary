<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             668c5b6ff0bed             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Salary; class Asset extends Container { public function wigskegsqequoeks() { $this->qcsmikeggeemccuu("\141\144\x6d\x69\156\x5f\x69\156\x69\x74", [$this, "\145\156\161\x75\x65\165\145"]); } public function enqueue() { if (!($eygsasmqycagyayw = $this->miocmcoykayoyyau())) { goto eyiamcekkgkiawqy; } $eygsasmqycagyayw->ayeieigcckcmsikq($eygsasmqycagyayw->owygwqwawqoiusis("\x61\x64\155\151\156", $eygsasmqycagyayw->get("\x61\144\155\151\x6e\x2e\152\163"))->simswskycwagoeqy())->ikqyiskqaaymscgw("\x61\152\141\170", Ajax::myikkigscysoykgy); eyiamcekkgkiawqy: } }
