<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6684010874872             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Salary; class Asset extends Container { public function wigskegsqequoeks() { $this->qcsmikeggeemccuu("\141\x64\x6d\151\156\x5f\151\x6e\x69\164", [$this, "\145\156\x71\x75\145\165\x65"]); } public function enqueue() { if (!($eygsasmqycagyayw = $this->miocmcoykayoyyau())) { goto eyiamcekkgkiawqy; } $eygsasmqycagyayw->ayeieigcckcmsikq($eygsasmqycagyayw->owygwqwawqoiusis("\141\144\x6d\x69\156", $eygsasmqycagyayw->get("\x61\x64\x6d\151\156\x2e\152\163"))->simswskycwagoeqy())->ikqyiskqaaymscgw("\x61\152\141\x78", Ajax::myikkigscysoykgy); eyiamcekkgkiawqy: } }
