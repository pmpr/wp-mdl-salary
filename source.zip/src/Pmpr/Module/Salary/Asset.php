<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66ce11ba45ec2             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Salary; class Asset extends Container { public function wigskegsqequoeks() { $this->waqewsckuayqguos("\142\x65\146\157\x72\145\137\145\156\x71\165\x65\x75\x65\137\x62\141\143\x6b\145\156\144\137\141\163\x73\x65\164\163", [$this, "\145\156\x71\165\x65\x75\x65"]); } public function enqueue() { if (!($eygsasmqycagyayw = $this->miocmcoykayoyyau())) { goto kqgcyoscsusgoaqi; } $eygsasmqycagyayw->ayeieigcckcmsikq($eygsasmqycagyayw->owygwqwawqoiusis("\x61\x64\x6d\x69\x6e", $eygsasmqycagyayw->get("\x61\144\155\x69\x6e\x2e\x6a\163"))->simswskycwagoeqy())->ikqyiskqaaymscgw("\141\152\x61\x78", Ajax::myikkigscysoykgy); kqgcyoscsusgoaqi: } }
